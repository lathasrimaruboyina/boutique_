import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credintials',
  templateUrl: './credintials.component.html',
  styleUrls: ['./credintials.component.css']
})
export class CredintialsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
